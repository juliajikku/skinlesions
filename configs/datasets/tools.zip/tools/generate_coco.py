import os
import cv2
import json
import random

IMG_DIR = "dataset/ISIC2018/imgs"
MASK_DIR = "dataset/ISIC2018/mask"

images = sorted([f for f in os.listdir(IMG_DIR) if f.endswith(".jpg")])

random.seed(42)
random.shuffle(images)

n = len(images)
train_imgs = images[:int(0.8*n)]
val_imgs = images[int(0.8*n):int(0.9*n)]
test_imgs = images[int(0.9*n):]

def create_coco(img_list, output_file):

    coco = {
        "images": [],
        "annotations": [],
        "categories": [{"id":1,"name":"lesion"}]
    }

    ann_id = 1

    for img_id, img_name in enumerate(img_list):

        mask_name = img_name.replace(".jpg","_segmentation.png")
        mask_path = os.path.join(MASK_DIR, mask_name)

        if not os.path.exists(mask_path):
            continue

        mask = cv2.imread(mask_path, 0)

        cnts,_ = cv2.findContours(
            mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )

        if len(cnts)==0:
            continue

        largest = max(cnts,key=cv2.contourArea)

        x,y,w,h = cv2.boundingRect(largest)

        img = cv2.imread(os.path.join(IMG_DIR,img_name))
        H,W = img.shape[:2]

        coco["images"].append({
            "id": img_id,
            "file_name": img_name,
            "width": W,
            "height": H
        })

        coco["annotations"].append({
            "id": ann_id,
            "image_id": img_id,
            "category_id": 1,
            "bbox": [x,y,w,h],
            "area": w*h,
            "iscrowd": 0
        })

        ann_id += 1

    with open(output_file,"w") as f:
        json.dump(coco,f)

create_coco(train_imgs,"instances_train.json")
create_coco(val_imgs,"instances_val.json")
create_coco(test_imgs,"instances_test.json")

print("Done")
